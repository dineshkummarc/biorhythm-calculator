<?php
$_GET['p'] = 'proverbs';
require_once realpath($_SERVER['DOCUMENT_ROOT']).'/index.php';