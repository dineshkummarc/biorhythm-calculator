// This service worker doesn't actually do anything!
self.addEventListener('fetch', function(event) {});