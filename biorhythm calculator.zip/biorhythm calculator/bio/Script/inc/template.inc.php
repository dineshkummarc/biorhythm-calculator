<?php
function template($filename): string {
  return __DIR__.'/../templates/'.$filename.'.tpl.php';
}