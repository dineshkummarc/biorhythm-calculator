<meta name="description" content="<?php echo $bmi_desc; ?>" />
<meta property="og:title" content="<?php echo $bmi_title; ?>" />
<meta property="og:description" content="<?php echo $bmi_desc; ?>" />
<?php
include template('head.common');
?>