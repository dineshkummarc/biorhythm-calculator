<a href="#0" class="cd-top js-cd-top rounded">Top</a>
<script src="<?php echo $cdn_url; ?>/static/js/to-top.js"></script>