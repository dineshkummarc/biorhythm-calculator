<?php
include template('script.common');
?>
<script src="<?php echo $cdn_url; ?>/static/js/manipulation.js"></script>