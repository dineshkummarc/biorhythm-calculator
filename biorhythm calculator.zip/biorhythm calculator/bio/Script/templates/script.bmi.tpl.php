<?php
include template('script.common');
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.7.9/angular.min.js" integrity="sha256-b5NvmvUcyr0wpBOLnNbaWH5zKQAivhj8yMYhfXEumQA=" crossorigin="anonymous"></script>
<script src="<?php echo $cdn_url; ?>/static/js/scripts.js?v=10"></script>
<script src="<?php echo $cdn_url; ?>/static/js/bmi.js"></script>